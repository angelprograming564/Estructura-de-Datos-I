package com.mycompany.comparativaestructuras;

//Angel Felipe Olivera Salggado y Juan Sebasttian Alvarez Muñoz

// Librerías obligatorias solicitadas por el profesor
import java.util.LinkedList; // Implementación física (nodos y punteros)
import java.util.Queue;      // Interfaz que obliga el comportamiento FIFO
import java.util.List;       // Interfaz para manejo de colecciones lineales

public class ComparativaEstructuras {

    public static void main(String[] args) {
        // 1. LISTA: Almacena todos los procesos (Uso: Inventario/Gestión)
        List<Proceso> listaSistema = new LinkedList<>();
        
        // Simulación de carga de programas en la memoria RAM
        listaSistema.add(new Proceso("Base de Datos", 2000));
        listaSistema.add(new Proceso("Compilador Java", 1500));
        listaSistema.add(new Proceso("Kernel SO", 3000));

        System.out.println("=== LISTA GENERAL (Estructura Lineal) ===");
        // Recorrido de la lista: acceso secuencial a cada nodo
        for (Proceso p : listaSistema) {
            System.out.println("Cargado: " + p);
        }

        // 2. COLA: Representa la fila de espera frente al procesador
        Queue<Proceso> colaEjecucion = new LinkedList<>();
        
        // Transferencia: de almacenamiento (Lista) a ejecución (Cola)
        colaEjecucion.addAll(listaSistema);

        System.out.println("\n=== COLA DE EJECUCIÓN (FIFO) ===");
        
        // Ciclo de procesamiento: mientras existan tareas pendientes
        while (!colaEjecucion.isEmpty()) {
            
            // .poll() : Saca al primero de la fila (Acción FIFO pura)
            Proceso actual = colaEjecucion.poll(); 
            
            System.out.println("Ejecutando: " + actual.nombre + "...");
            
            try {
                // Simulación del tiempo que el CPU tarda en procesar el nodo
                Thread.sleep(1000); 
            } catch (InterruptedException e) {}
            
            System.out.println(">> Finalizado: " + actual.nombre);
        }
        // Al final, la lista sigue llena pero la cola queda vacía
    }
}



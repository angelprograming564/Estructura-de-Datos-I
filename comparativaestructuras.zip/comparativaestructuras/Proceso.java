package com.mycompany.comparativaestructuras;



//Angel Felipe Olivera Salggado y Juan Sebasttian Alvarez Muñoz


// Esta clase es el "Nodo" que contiene la información de cada tarea
public class Proceso {
    // Atributos: Representan los datos que viajan en la estructura
    String nombre; // Identificador del proceso
    int tiempo;    // Carga de trabajo (duración)

    // Constructor: "Fabrica" el objeto y asigna los valores iniciales
    public Proceso(String nombre, int tiempo) {
        this.nombre = nombre;
        this.tiempo = tiempo;
    }

    // Método toString: Convierte el objeto en texto legible para la consola
    @Override
    public String toString() {
        // Formato visual para que el usuario entienda qué se está procesando
        return nombre + " [" + tiempo + "ms]";
    }
}
